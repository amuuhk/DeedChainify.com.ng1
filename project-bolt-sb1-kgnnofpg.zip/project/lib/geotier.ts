export const geoTierData: Record<string, Record<string, string[]>> = {
  KANO: {
    TIER1_CITY_50K: ['Kano Municipal', 'Fagge', 'Dala', 'Nasarawa', 'Gwammaja'],
    TIER2_SEMI_45K: ['Tarauni', 'Ungogo', 'Kumbotso', 'Dawakin Kudu'],
    TIER3_TOWN_35K: ['Bichi', 'Kiru', 'Rano', 'Gaya'],
    TIER4_SEMI_VILLAGE_25K: ['Wudil', 'Kibiya', 'Makarfi'],
    TIER5_VILLAGE_10K: ['Ajingi', 'Gezawa', 'Minjibir'],
  },
  ABUJA: {
    TIER1_CITY_50K: ['Municipal Area Council - Garki', 'Wuse', 'Maitama', 'Asokoro'],
    TIER2_SEMI_45K: ['Bwari', 'Kubwa', 'Gwagwalada'],
    TIER3_TOWN_35K: ['Kuje', 'Lugbe'],
    TIER4_SEMI_VILLAGE_25K: ['Abaji', 'Kwali'],
    TIER5_VILLAGE_10K: ['Zuba', 'Dutse'],
  },
  LAGOS: {
    TIER1_CITY_50K: ['Ikeja', 'Victoria Island', 'Ikoyi', 'Lekki Phase 1'],
    TIER2_SEMI_45K: ['Surulere', 'Yaba', 'Ajah', 'Ilupeju'],
    TIER3_TOWN_35K: ['Oshodi', 'Mushin', 'Egbeda'],
    TIER4_SEMI_VILLAGE_25K: ['Ikorodu', 'Epe'],
    TIER5_VILLAGE_10K: ['Badagry', 'Iba'],
  },
};

export function getTierPrice(state: string, lga: string): { price: number; tier: number } {
  const stateData = geoTierData[state.toUpperCase()];
  if (!stateData) return { price: 25000, tier: 3 };

  for (const [tierKey, lgas] of Object.entries(stateData)) {
    if (lgas.includes(lga)) {
      if (tierKey.includes('50K')) return { price: 50000, tier: 1 };
      if (tierKey.includes('45K')) return { price: 45000, tier: 2 };
      if (tierKey.includes('35K')) return { price: 35000, tier: 3 };
      if (tierKey.includes('25K')) return { price: 25000, tier: 4 };
      if (tierKey.includes('10K')) return { price: 10000, tier: 5 };
    }
  }
  return { price: 25000, tier: 3 };
}

export const TIER_LABELS: Record<number, string> = {
  1: 'Tier 1 (City Center)',
  2: 'Tier 2 (Semi-Urban)',
  3: 'Tier 3 (Town)',
  4: 'Tier 4 (Semi-Village)',
  5: 'Tier 5 (Village)',
};
