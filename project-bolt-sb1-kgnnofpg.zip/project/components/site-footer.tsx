'use client';

import Link from 'next/link';
import { ShieldCheck } from 'lucide-react';
import { useLogo } from '@/lib/logo-context';

export function SiteFooter() {
  const { logoUrl } = useLogo();

  return (
    <footer className="border-t border-border/60 bg-muted/30">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2 font-bold text-lg">
              {logoUrl ? (
                <img src={logoUrl} alt="DeedChainify" className="h-8 w-8 rounded-lg object-cover" />
              ) : (
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                  <ShieldCheck size={18} />
                </div>
              )}
              <span className="font-jakarta">DeedChainify</span>
            </div>
            <p className="mt-3 text-sm text-muted-foreground">
              Rebuilding trust in property. One digital record at a time.
            </p>
          </div>

          <div>
            <h4 className="text-sm font-semibold">Product</h4>
            <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
              <li><Link href="/verify" className="hover:text-foreground">Verify Land</Link></li>
              <li><Link href="/pricing" className="hover:text-foreground">Documenting</Link></li>
              <li><Link href="/signup" className="hover:text-foreground">Get DCID</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold">Portals</h4>
            <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
              <li><Link href="/dashboard/state" className="hover:text-foreground">State Govt</Link></li>
              <li><Link href="/dashboard/bank" className="hover:text-foreground">Bank Portal</Link></li>
              <li><Link href="/dashboard/agent" className="hover:text-foreground">Agent Portal</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold">Company</h4>
            <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
              <li><Link href="/about" className="hover:text-foreground">About</Link></li>
              <li><Link href="/contact" className="hover:text-foreground">Contact</Link></li>
            </ul>
          </div>
        </div>

        <div className="mt-8 border-t border-border/60 pt-6 text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} DeedChainify OS. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
