import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface SealRequest {
  transferId: string;
  dcTitle: string;
  pdfHash: string;
  userId: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { transferId, dcTitle, pdfHash, userId } = await req.json() as SealRequest;

    if (!transferId || !dcTitle || !pdfHash) {
      return new Response(
        JSON.stringify({ error: "Missing required fields: transferId, dcTitle, pdfHash" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const custodiumSecret = Deno.env.get("CUSTODIUM_SECRET_KEY") || "deedchainify-custodium-default-secret-v1";

    const supabase = createClient(supabaseUrl, serviceRoleKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });

    // Get the last block for chain linking
    const { data: lastBlock } = await supabase
      .from("private_ledger")
      .select("pdf_hash")
      .order("timestamp", { ascending: false })
      .limit(1)
      .maybeSingle();

    const previousHash = lastBlock?.pdf_hash || "GENESIS_BLOCK";

    // Generate nonce
    const nonce = crypto.randomUUID();

    // Create block data for signing
    const blockData = {
      transferId,
      dcTitle,
      pdfHash,
      previousHash,
      timestamp: new Date().toISOString(),
      nonce,
    };

    // HMAC-SHA256 signature using server secret
    const enc = new TextEncoder();
    const key = await crypto.subtle.importKey(
      "raw",
      enc.encode(custodiumSecret),
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["sign"],
    );
    const sigBuffer = await crypto.subtle.sign("HMAC", key, enc.encode(JSON.stringify(blockData)));
    const signature = Array.from(new Uint8Array(sigBuffer)).map((b) => b.toString(16).padStart(2, "0")).join("");

    // Insert the new block
    const { data: newBlock, error: insertError } = await supabase
      .from("private_ledger")
      .insert({
        transfer_id: transferId,
        dc_title: dcTitle,
        pdf_hash: pdfHash,
        previous_hash: previousHash,
        signature,
        nonce,
        status: "SEALED",
      })
      .select()
      .single();

    if (insertError) throw insertError;

    // Update the transfer record with custodium proof
    await supabase
      .from("transfers")
      .update({
        pdf_hash: pdfHash,
        ledger_id: newBlock.id,
        signature,
      })
      .eq("transfer_id", transferId);

    return new Response(
      JSON.stringify({
        pdfHash,
        ledgerId: newBlock.id,
        signature,
        previousHash,
        timestamp: blockData.timestamp,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message || "Failed to seal to custodium" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
