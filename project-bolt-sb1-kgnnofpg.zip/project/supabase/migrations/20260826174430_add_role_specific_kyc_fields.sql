/*
# Add role-specific KYC fields to profiles

## Overview
Adds columns to the `profiles` table to support role-specific signup
requirements for Landlord (CAC number), Chief (traditional title +
title proof), and Barrister (Bar ID + law practice license). All roles
already require NIN; these columns capture the additional credentials
needed for KYC verification via Youverify.

## Modified Tables
1. `profiles` — adds 5 new nullable text columns:
   - `cac_number` — Corporate Affairs Commission number (landlord only)
   - `traditional_title` — e.g. "Sarkin Kano", "Baale of Eti-Osa" (chief only)
   - `title_proof` — description of traditional title proof document (chief only)
   - `bar_id` — Nigerian Bar Association ID (barrister only)
   - `law_license` — Law practice license number (barrister only)

## Security
- No new RLS policies needed. Existing owner-scoped CRUD on profiles
  already covers these columns (auth.uid() = id).
- These columns are user-editable only by the profile owner, same as
  all other profile columns.
*/

ALTER TABLE profiles ADD COLUMN IF NOT EXISTS cac_number text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS traditional_title text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS title_proof text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS bar_id text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS law_license text;