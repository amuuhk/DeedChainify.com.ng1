/*
# Add referral_code column to profiles

## Overview
Adds a `referral_code` column to the `profiles` table to support
the referral system in the signup flow.

## Modified Tables
1. `profiles` — added column:
   - referral_code (text, nullable) — optional referral code from another user
*/

ALTER TABLE profiles ADD COLUMN IF NOT EXISTS referral_code text;
