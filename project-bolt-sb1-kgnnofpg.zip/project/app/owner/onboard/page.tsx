'use client';

import { useState, useEffect, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft, ShieldCheck, Eye, CheckCircle, Loader2, Plus, Trash2, Users } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/lib/auth-context';
import { supabase } from '@/lib/supabase/client';
import {
  STATE_CODES, LGA_CODES, PLOT_TYPES, generateDCTitle,
  getOnboardingFee, getFeeTier, formatNaira,
} from '@/lib/dcid';
import { SiteHeader } from '@/components/site-header';

type CoOwner = {
  name: string;
  nin: string;
  phone: string;
  share: string;
};

function OnboardForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { profile } = useAuth();
  const isPrivate = searchParams.get('type') === 'private';

  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({
    state: 'Kano',
    lga: 'Fagge',
    layoutName: '',
    blockNo: '',
    plotNo: '',
    plotType: 'Residential',
    sizeSqm: 450,
    gpsLat: 12.0,
    gpsLong: 8.5167,
    neighbor1: '',
    neighbor2: '',
    neighbor3: '',
  });

  const [coOwners, setCoOwners] = useState<CoOwner[]>([
    { name: '', nin: '', phone: '', share: '100' },
  ]);

  const availableLGAs = Object.keys(LGA_CODES[STATE_CODES[form.state]] || {});
  const fee = isPrivate ? getOnboardingFee(form.lga) : 0;
  const tier = getFeeTier(form.lga);

  const totalShare = coOwners.reduce((sum, o) => sum + (parseFloat(o.share) || 0), 0);
  const shareValid = Math.abs(totalShare - 100) < 0.01;

  useEffect(() => {
    if (!profile) router.push('/login');
  }, [profile, router]);

  function addCoOwner() {
    if (coOwners.length >= 50) {
      toast.error('Maximum 50 owners allowed');
      return;
    }
    setCoOwners([...coOwners, { name: '', nin: '', phone: '', share: '' }]);
  }

  function removeCoOwner(idx: number) {
    if (coOwners.length === 1) return;
    setCoOwners(coOwners.filter((_, i) => i !== idx));
  }

  function updateCoOwner(idx: number, field: keyof CoOwner, value: string) {
    setCoOwners(coOwners.map((o, i) => (i === idx ? { ...o, [field]: value } : o)));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!profile) return;
    if (!shareValid) {
      toast.error('Total ownership share must equal 100%');
      return;
    }
    const hasOwnerInfo = coOwners.some((o) => o.name.trim());
    if (!hasOwnerInfo) {
      toast.error('At least one owner is required');
      return;
    }
    setSubmitting(true);

    try {
      const { data: countData } = await supabase
        .from('properties')
        .select('id', { count: 'exact', head: true });

      const seq = (countData?.length || 0) + 1;
      const dcTitle = generateDCTitle(
        form.state, form.lga, form.layoutName, form.blockNo,
        form.plotType, form.plotNo, seq,
      );

      const { data, error } = await supabase.from('properties').insert({
        dc_title: dcTitle,
        owner_id: profile.id,
        owner_dc_id: profile.dc_id,
        owner_name: profile.full_name,
        state: form.state,
        lga: form.lga,
        layout_name: form.layoutName,
        block_no: form.blockNo,
        plot_no: form.plotNo,
        plot_type: PLOT_TYPES[form.plotType] || 'P',
        gps_lat: form.gpsLat,
        gps_long: form.gpsLong,
        size_sqm: form.sizeSqm,
        status: 'PENDING',
        listing_type: isPrivate ? 'PRIVATE' : 'PUBLIC',
        private_qr_token: crypto.randomUUID(),
      }).select().single();

      if (error) throw error;

      // Insert co-owners
      const ownersToInsert = coOwners
        .filter((o) => o.name.trim())
        .map((o) => ({
          property_id: data.id,
          name: o.name,
          nin: o.nin || null,
          phone: o.phone || null,
          share_pct: parseFloat(o.share) || 0,
        }));
      if (ownersToInsert.length > 0) {
        await supabase.from('property_owners').insert(ownersToInsert);
      }

      if (isPrivate) {
        await supabase.from('payments').insert({
          type: 'PRIVATE_ONBOARD',
          amount: fee,
          dc_title: dcTitle,
          dc_id: profile.dc_id,
          user_id: profile.id,
          status: 'SUCCESS',
        });
      }

      const neighbors = [form.neighbor1, form.neighbor2, form.neighbor3].filter(Boolean);
      if (neighbors.length > 0) {
        const neighborInserts = neighbors.map((phone) => ({
          property_id: data.id,
          neighbor_phone: phone,
          status: 'PENDING',
        }));
        await supabase.from('neighbor_requests').insert(neighborInserts);
      }

      toast.success('Property onboarded!', { description: dcTitle });
      router.push(`/owner/${dcTitle}`);
    } catch (err: any) {
      toast.error(err.message || 'Failed to onboard property');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <>
      <SiteHeader />
      <main className="mx-auto max-w-3xl px-4 py-8 sm:px-6">
        <Link href="/owner" className="mb-4 inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft size={16} /> Back to dashboard
        </Link>

        <div className="mb-6 flex items-center gap-3">
          <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${isPrivate ? 'bg-primary/10' : 'bg-secondary/10'}`}>
            {isPrivate ? <ShieldCheck size={24} className="text-primary" /> : <Eye size={24} className="text-secondary" />}
          </div>
          <div>
            <h1 className="font-jakarta text-2xl font-bold">
              {isPrivate ? 'Private Onboarding' : 'Public Listing'}
            </h1>
            <p className="text-sm text-muted-foreground">
              {isPrivate ? `Geo-tier pricing: ${formatNaira(fee)} (${tier.tier})` : 'Free listing, anyone can scan to verify'}
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <Card className="border-border/60">
            <CardHeader>
              <CardTitle className="font-jakarta text-lg">Property Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="state">State</Label>
                  <Select value={form.state} onValueChange={(v) => setForm({ ...form, state: v, lga: Object.keys(LGA_CODES[STATE_CODES[v]] || {})[0] || '' })}>
                    <SelectTrigger id="state"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {Object.keys(STATE_CODES).map((s) => (
                        <SelectItem key={s} value={s}>{s}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lga">LGA</Label>
                  <Select value={form.lga} onValueChange={(v) => setForm({ ...form, lga: v })}>
                    <SelectTrigger id="lga"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {availableLGAs.map((l) => (
                        <SelectItem key={l} value={l}>{l}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="layout">Layout Name</Label>
                <Input
                  id="layout"
                  required
                  value={form.layoutName}
                  onChange={(e) => setForm({ ...form, layoutName: e.target.value })}
                  placeholder="e.g. FAGGE"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="block">Block No</Label>
                  <Input id="block" required value={form.blockNo} onChange={(e) => setForm({ ...form, blockNo: e.target.value })} placeholder="12" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="plot">Plot No</Label>
                  <Input id="plot" required value={form.plotNo} onChange={(e) => setForm({ ...form, plotNo: e.target.value })} placeholder="04" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="type">Plot Type</Label>
                  <Select value={form.plotType} onValueChange={(v) => setForm({ ...form, plotType: v })}>
                    <SelectTrigger id="type"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {Object.keys(PLOT_TYPES).map((t) => (
                        <SelectItem key={t} value={t}>{t}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="size">Size (sqm)</Label>
                  <Input id="size" type="number" required value={form.sizeSqm} onChange={(e) => setForm({ ...form, sizeSqm: parseInt(e.target.value) || 0 })} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lat">GPS Lat</Label>
                  <Input id="lat" type="number" step="any" value={form.gpsLat} onChange={(e) => setForm({ ...form, gpsLat: parseFloat(e.target.value) || 0 })} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="long">GPS Long</Label>
                  <Input id="long" type="number" step="any" value={form.gpsLong} onChange={(e) => setForm({ ...form, gpsLong: parseFloat(e.target.value) || 0 })} />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Co-Ownership */}
          <Card className="border-border/60">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="font-jakarta text-lg flex items-center gap-2">
                    <Users size={18} className="text-primary" />
                    Co-Ownership
                  </CardTitle>
                  <CardDescription className="mt-1">
                    Add 1 to 50 owners. Example: Ahmed 40%, Musa 30%, Fatima 30%
                  </CardDescription>
                </div>
                <Button type="button" variant="outline" size="sm" onClick={addCoOwner}>
                  <Plus size={14} className="mr-1.5" />
                  Add Owner
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {coOwners.map((owner, idx) => (
                <div key={idx} className="rounded-lg border border-border/60 p-3">
                  <div className="mb-2 flex items-center justify-between">
                    <span className="text-xs font-medium text-muted-foreground">Owner {idx + 1}</span>
                    {coOwners.length > 1 && (
                      <Button type="button" variant="ghost" size="sm" onClick={() => removeCoOwner(idx)}>
                        <Trash2 size={14} className="text-red-500" />
                      </Button>
                    )}
                  </div>
                  <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                    <Input placeholder="Name" required value={owner.name} onChange={(e) => updateCoOwner(idx, 'name', e.target.value)} />
                    <Input placeholder="NIN" value={owner.nin} onChange={(e) => updateCoOwner(idx, 'nin', e.target.value)} />
                    <Input placeholder="Phone" value={owner.phone} onChange={(e) => updateCoOwner(idx, 'phone', e.target.value)} />
                    <div className="relative">
                      <Input placeholder="Share %" type="number" required value={owner.share} onChange={(e) => updateCoOwner(idx, 'share', e.target.value)} />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">%</span>
                    </div>
                  </div>
                </div>
              ))}
              <div className={`flex items-center justify-between rounded-lg p-3 text-sm ${shareValid ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>
                <span>Total Share:</span>
                <span className="font-bold">{totalShare.toFixed(0)}% {shareValid ? '(Valid)' : '(Must equal 100%)'}</span>
              </div>
            </CardContent>
          </Card>

          {/* Neighbor verification */}
          <Card className="border-border/60">
            <CardHeader>
              <CardTitle className="font-jakarta text-lg">Neighbor Verification</CardTitle>
              <CardDescription>Send verification requests to up to 3 neighbors</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="space-y-1.5">
                  <Label htmlFor={`neighbor${i}`}>Neighbor {i} Phone</Label>
                  <Input
                    id={`neighbor${i}`}
                    value={form[`neighbor${i}` as keyof typeof form] as string}
                    onChange={(e) => setForm({ ...form, [`neighbor${i}`]: e.target.value } as any)}
                    placeholder="08012345678"
                  />
                </div>
              ))}
            </CardContent>
          </Card>

          <Button type="submit" size="lg" className="w-full" disabled={submitting || !shareValid}>
            {submitting ? (
              <><Loader2 size={18} className="mr-2 animate-spin" /> Onboarding...</>
            ) : (
              <>
                <CheckCircle size={18} className="mr-2" />
                {isPrivate ? `Pay ${formatNaira(fee)} & Onboard` : 'Create Free Listing'}
              </>
            )}
          </Button>
        </form>
      </main>
    </>
  );
}

export default function OnboardPage() {
  return (
    <Suspense fallback={<div className="flex h-screen items-center justify-center"><Loader2 className="animate-spin" /></div>}>
      <OnboardForm />
    </Suspense>
  );
}
