'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ShieldCheck, ArrowRight, Eye, EyeOff, Lock } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/lib/supabase/client';
import { SiteHeader } from '@/components/site-header';
import { TermsConsent } from '@/components/terms-consent';

export default function AdminLoginPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [agreed, setAgreed] = useState(false);
  const [form, setForm] = useState({ email: '', password: '' });

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!agreed) return;
    setLoading(true);

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: form.email,
        password: form.password,
      });

      if (error) throw error;

      const { data: profileData } = await supabase
        .from('profiles')
        .select('role')
        .eq('id', data.user.id)
        .maybeSingle();

      const role = (profileData as { role: string } | null)?.role;

      if (role !== 'admin') {
        await supabase.auth.signOut();
        toast.error('Access denied', { description: 'This portal is for administrators only.' });
        setLoading(false);
        return;
      }

      toast.success('Welcome, Admin');
      router.push('/dashboard/admin');
    } catch (err: any) {
      toast.error(err.message || 'Login failed');
      setLoading(false);
    }
  }

  return (
    <>
      <SiteHeader />
      <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center px-4 py-12">
        <Card className="w-full max-w-md animate-scale-in border-border/60">
          <CardHeader className="text-center">
            <div className="mx-auto mb-2 flex h-12 w-12 items-center justify-center rounded-xl bg-primary text-primary-foreground">
              <Lock size={24} />
            </div>
            <CardTitle className="font-jakarta text-2xl">Admin Portal</CardTitle>
            <CardDescription>Restricted access — administrators only</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Admin Email</Label>
                <Input
                  id="email"
                  type="email"
                  required
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  placeholder="admin@deedchainify.com"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={form.password}
                    onChange={(e) => setForm({ ...form, password: e.target.value })}
                    placeholder="Your password"
                  />
                  <button
                    type="button"
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>

              <TermsConsent checked={agreed} onCheckedChange={setAgreed} />

              <Button type="submit" className="w-full" size="lg" disabled={loading || !agreed}>
                {loading ? 'Signing in...' : 'Access Admin Dashboard'}
                {!loading && <ArrowRight size={18} className="ml-2" />}
              </Button>
            </form>

            <div className="mt-4 flex items-center justify-center gap-2 rounded-lg border border-amber-300 bg-amber-50 p-3">
              <ShieldCheck size={16} className="text-amber-600" />
              <p className="text-xs text-amber-800">
                This portal is hidden from public navigation. Admin accounts cannot be created via the signup page.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
