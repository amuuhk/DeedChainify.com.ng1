'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  TrendingUp, AlertTriangle, Building2, Users, Wallet,
  Activity, Download, Loader2, ShieldCheck, Home, Scale,
  Crown, User, Search, FileText, Link2, Banknote, CheckCircle,
  Clock, XCircle, MapPin, Percent,
} from 'lucide-react';
import { supabase } from '@/lib/supabase/client';
import type { Payment, Property, Transfer, PropertyOwner, Profile } from '@/lib/supabase/client';
import { SiteHeader } from '@/components/site-header';
import { StatusBadge } from '@/components/status-badge';
import { formatNaira } from '@/lib/dcid';
import { useAuth } from '@/lib/auth-context';
import { toast } from 'sonner';

type TabId = 'overview' | 'properties' | 'co_ownership' | 'transfers' | 'users' | 'payments';

export default function AdminDashboard() {
  const router = useRouter();
  const { profile, loading: authLoading } = useAuth();
  const [payments, setPayments] = useState<Payment[]>([]);
  const [properties, setProperties] = useState<Property[]>([]);
  const [transfers, setTransfers] = useState<Transfer[]>([]);
  const [coOwners, setCoOwners] = useState<PropertyOwner[]>([]);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<TabId>('overview');
  const [search, setSearch] = useState('');

  useEffect(() => {
    if (!authLoading) {
      if (!profile) {
        router.push('/login');
        return;
      }
      if (profile.role !== 'admin') {
        router.push('/owner');
        return;
      }
      fetchAll();
    }
  }, [authLoading, profile, router]);

  async function fetchAll() {
    const [payRes, propRes, transRes, ownerRes, profRes] = await Promise.all([
      supabase.from('payments').select('*').order('created_at', { ascending: false }).limit(50),
      supabase.from('properties').select('*').order('created_at', { ascending: false }),
      supabase.from('transfers').select('*').order('created_at', { ascending: false }).limit(30),
      supabase.from('property_owners').select('*').order('created_at', { ascending: false }),
      supabase.from('profiles').select('*').order('created_at', { ascending: false }).limit(50),
    ]);
    setPayments(payRes.data as Payment[] || []);
    setProperties(propRes.data as Property[] || []);
    setTransfers(transRes.data as Transfer[] || []);
    setCoOwners(ownerRes.data as PropertyOwner[] || []);
    setProfiles(profRes.data as Profile[] || []);
    setLoading(false);
  }

  const totalRevenue = payments.reduce((sum, p) => sum + p.amount, 0);
  const disputedCount = properties.filter((p) => p.status === 'RED' || p.status === 'DISPUTED').length;
  const pledgedCount = properties.filter((p) => p.is_pledged).length;
  const verifiedCount = properties.filter((p) => p.status === 'GREEN' || p.status === 'VERIFIED').length;
  const pendingCount = properties.filter((p) => p.status === 'PENDING' || p.status === 'YELLOW').length;
  const pendingTransfers = transfers.filter((t) => t.status === 'PENDING').length;
  const approvedTransfers = transfers.filter((t) => t.status === 'APPROVED').length;

  const roleBreakdown: Record<string, number> = {};
  profiles.forEach((p) => {
    roleBreakdown[p.role] = (roleBreakdown[p.role] || 0) + 1;
  });

  const coOwnerByProperty: Record<string, PropertyOwner[]> = {};
  coOwners.forEach((o) => {
    const key = o.property_id;
    if (!coOwnerByProperty[key]) coOwnerByProperty[key] = [];
    coOwnerByProperty[key].push(o);
  });

  const multiOwnerProperties = properties.filter((p) => (coOwnerByProperty[p.id] || []).length > 1);

  function exportCSV() {
    const headers = ['DC Title', 'Owner', 'State', 'LGA', 'Size (sqm)', 'Status', 'Pledged', 'Co-Owners', 'Created'];
    const rows = properties.map((p) => [
      p.dc_title,
      p.owner_name || '',
      p.state,
      p.lga,
      p.size_sqm,
      p.status,
      p.is_pledged ? 'YES' : 'NO',
      (coOwnerByProperty[p.id] || []).length,
      p.created_at,
    ]);
    const csv = [headers, ...rows].map((r) => r.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'admin-properties.csv';
    a.click();
    toast.success('CSV exported');
  }

  const filteredProperties = properties.filter((p) => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      p.dc_title.toLowerCase().includes(q) ||
      (p.owner_name || '').toLowerCase().includes(q) ||
      p.state.toLowerCase().includes(q) ||
      p.lga.toLowerCase().includes(q)
    );
  });

  if (authLoading || loading) {
    return (
      <>
        <SiteHeader />
        <div className="flex h-[calc(100vh-4rem)] items-center justify-center">
          <Loader2 className="animate-spin text-primary" />
        </div>
      </>
    );
  }

  const tabs: { id: TabId; label: string; icon: typeof Home }[] = [
    { id: 'overview', label: 'Overview', icon: Activity },
    { id: 'properties', label: 'Properties', icon: Building2 },
    { id: 'co_ownership', label: 'Co-Ownership', icon: Users },
    { id: 'transfers', label: 'Transfers', icon: FileText },
    { id: 'users', label: 'Users', icon: User },
    { id: 'payments', label: 'Payments', icon: Wallet },
  ];

  return (
    <>
      <SiteHeader />
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground">
              <ShieldCheck size={22} />
            </div>
            <div>
              <h1 className="font-jakarta text-2xl font-bold">Admin Dashboard</h1>
              <p className="text-sm text-muted-foreground">Full platform control — revenue, properties, co-ownership, transfers & users</p>
            </div>
          </div>
          <Button variant="outline" onClick={exportCSV}>
            <Download size={16} className="mr-2" />
            Export CSV
          </Button>
        </div>

        {/* Stat cards */}
        <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-4 lg:grid-cols-6">
          {[
            { label: 'Total Revenue', value: formatNaira(totalRevenue), icon: Wallet, color: 'text-primary' },
            { label: 'Properties', value: properties.length, icon: Building2, color: 'text-blue-600' },
            { label: 'Verified', value: verifiedCount, icon: CheckCircle, color: 'text-green-600' },
            { label: 'Disputed', value: disputedCount, icon: AlertTriangle, color: 'text-red-600' },
            { label: 'Pledged', value: pledgedCount, icon: Banknote, color: 'text-orange-600' },
            { label: 'Users', value: profiles.length, icon: Users, color: 'text-secondary' },
          ].map((s) => (
            <Card key={s.label} className="border-border/60">
              <CardContent className="p-4">
                <s.icon size={20} className={s.color} />
                <p className="mt-2 font-jakarta text-xl font-bold">{s.value}</p>
                <p className="text-xs text-muted-foreground">{s.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Tabs */}
        <div className="mt-8 flex flex-wrap gap-2 border-b border-border/60 pb-px">
          {tabs.map((t) => {
            const Icon = t.icon;
            return (
              <button
                key={t.id}
                onClick={() => setActiveTab(t.id)}
                className={`flex items-center gap-1.5 rounded-t-lg px-4 py-2.5 text-sm font-medium transition-colors ${
                  activeTab === t.id
                    ? 'border-b-2 border-primary text-primary'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                <Icon size={16} />
                {t.label}
              </button>
            );
          })}
        </div>

        <div className="mt-6">
          {/* OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="grid gap-6 lg:grid-cols-2">
              <Card className="border-border/60">
                <CardHeader>
                  <CardTitle className="font-jakarta text-lg">Recent Transactions</CardTitle>
                </CardHeader>
                <CardContent>
                  {payments.length === 0 ? (
                    <p className="text-sm text-muted-foreground">No transactions yet</p>
                  ) : (
                    <div className="space-y-2">
                      {payments.slice(0, 10).map((p) => (
                        <div key={p.id} className="flex items-center justify-between border-b border-border/40 pb-2">
                          <div>
                            <p className="text-sm font-medium">{p.type}</p>
                            <p className="text-xs text-muted-foreground">
                              {p.dc_title || '-'} &middot; {new Date(p.created_at).toLocaleDateString()}
                            </p>
                          </div>
                          <span className="font-semibold text-sm">{formatNaira(p.amount)}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="border-border/60">
                <CardHeader>
                  <CardTitle className="font-jakarta text-lg">Fraud Alerts</CardTitle>
                </CardHeader>
                <CardContent>
                  {disputedCount === 0 ? (
                    <div className="flex flex-col items-center py-8 text-center">
                      <CheckCircle size={32} className="text-green-600" />
                      <p className="mt-2 text-sm text-muted-foreground">No disputes detected</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {properties.filter((p) => p.status === 'RED' || p.status === 'DISPUTED').map((p) => (
                        <div key={p.id} className="flex items-center gap-3 rounded-lg border border-red-300 bg-red-50 p-3">
                          <AlertTriangle size={18} className="text-red-600" />
                          <div className="flex-1">
                            <p className="text-sm font-medium">{p.dc_title}</p>
                            <p className="text-xs text-red-700">Status: {p.status}</p>
                          </div>
                          <Badge variant="outline" className="border-red-300 text-red-700">DISPUTED</Badge>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="border-border/60">
                <CardHeader>
                  <CardTitle className="font-jakarta text-lg">User Role Breakdown</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {Object.entries(roleBreakdown).map(([role, count]) => {
                      const Icon = role === 'admin' ? ShieldCheck : role === 'landlord' ? Home : role === 'chief' ? Crown : role === 'barrister' ? Scale : User;
                      return (
                        <div key={role} className="flex items-center justify-between border-b border-border/40 pb-2">
                          <div className="flex items-center gap-2">
                            <Icon size={16} className="text-muted-foreground" />
                            <span className="text-sm font-medium capitalize">{role}</span>
                          </div>
                          <Badge variant="secondary">{count}</Badge>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border/60">
                <CardHeader>
                  <CardTitle className="font-jakarta text-lg">Transfer Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="rounded-lg border border-yellow-300 bg-yellow-50 p-4 text-center">
                      <Clock size={24} className="mx-auto text-yellow-600" />
                      <p className="mt-2 font-jakarta text-2xl font-bold text-yellow-800">{pendingTransfers}</p>
                      <p className="text-xs text-yellow-700">Pending</p>
                    </div>
                    <div className="rounded-lg border border-green-300 bg-green-50 p-4 text-center">
                      <CheckCircle size={24} className="mx-auto text-green-600" />
                      <p className="mt-2 font-jakarta text-2xl font-bold text-green-800">{approvedTransfers}</p>
                      <p className="text-xs text-green-700">Approved</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* PROPERTIES */}
          {activeTab === 'properties' && (
            <div>
              <div className="mb-4 flex items-center gap-2">
                <div className="relative flex-1 max-w-sm">
                  <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Search by DC Title, owner, state, LGA..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="pl-9"
                  />
                </div>
                <Badge variant="outline">{filteredProperties.length} results</Badge>
              </div>
              <div className="space-y-2">
                {filteredProperties.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No properties found</p>
                ) : (
                  filteredProperties.slice(0, 30).map((p) => (
                    <div key={p.id} className="flex items-center justify-between rounded-lg border border-border/60 p-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-medium">{p.dc_title}</p>
                          {(coOwnerByProperty[p.id] || []).length > 1 && (
                            <Badge variant="secondary" className="gap-1">
                              <Users size={10} />
                              {(coOwnerByProperty[p.id] || []).length} owners
                            </Badge>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground flex items-center gap-1">
                          <MapPin size={10} />
                          {p.owner_name || 'Unknown'} &middot; {p.layout_name}, {p.lga}, {p.state} &middot; {p.size_sqm} sqm
                        </p>
                      </div>
                      <StatusBadge status={p.status} isPledged={p.is_pledged} bankName={p.bank_name} />
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* CO-OWNERSHIP */}
          {activeTab === 'co_ownership' && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
                {[
                  { label: 'Total Co-Owners', value: coOwners.length, icon: Users, color: 'text-primary' },
                  { label: 'Multi-Owner Properties', value: multiOwnerProperties.length, icon: Link2, color: 'text-blue-600' },
                  { label: 'Single-Owner Properties', value: properties.length - multiOwnerProperties.length, icon: Home, color: 'text-green-600' },
                  { label: 'Avg Owners/Property', value: properties.length > 0 ? (coOwners.length / properties.length).toFixed(1) : '0', icon: Percent, color: 'text-secondary' },
                ].map((s) => (
                  <Card key={s.label} className="border-border/60">
                    <CardContent className="p-4">
                      <s.icon size={20} className={s.color} />
                      <p className="mt-2 font-jakarta text-xl font-bold">{s.value}</p>
                      <p className="text-xs text-muted-foreground">{s.label}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <Card className="border-border/60">
                <CardHeader>
                  <CardTitle className="font-jakarta text-lg">Multi-Owner Properties (Co-Ownership)</CardTitle>
                </CardHeader>
                <CardContent>
                  {multiOwnerProperties.length === 0 ? (
                    <div className="flex flex-col items-center py-8 text-center">
                      <Users size={32} className="text-muted-foreground" />
                      <p className="mt-2 text-sm text-muted-foreground">No co-owned properties yet</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {multiOwnerProperties.map((prop) => {
                        const owners = coOwnerByProperty[prop.id] || [];
                        const totalShare = owners.reduce((sum, o) => sum + Number(o.share_pct), 0);
                        return (
                          <div key={prop.id} className="rounded-lg border border-border/60 p-4">
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="text-sm font-medium">{prop.dc_title}</p>
                                <p className="text-xs text-muted-foreground">
                                  {prop.layout_name}, {prop.lga}, {prop.state} &middot; {prop.size_sqm} sqm
                                </p>
                              </div>
                              <div className="flex items-center gap-2">
                                <Badge variant="secondary">{owners.length} owners</Badge>
                                <StatusBadge status={prop.status} isPledged={prop.is_pledged} bankName={prop.bank_name} />
                              </div>
                            </div>
                            <div className="mt-3 space-y-2">
                              {owners.map((o) => (
                                <div key={o.id} className="flex items-center justify-between rounded-md bg-muted/40 px-3 py-2">
                                  <div>
                                    <p className="text-sm font-medium">{o.name}</p>
                                    <p className="text-xs text-muted-foreground">
                                      {o.phone || 'No phone'} {o.nin ? `&middot; NIN: ${o.nin}` : ''}
                                    </p>
                                  </div>
                                  <Badge variant="outline" className={Number(o.share_pct) === 0 ? 'text-red-600' : ''}>
                                    {Number(o.share_pct).toFixed(2)}%
                                  </Badge>
                                </div>
                              ))}
                            </div>
                            <div className="mt-3">
                              <div className="flex justify-between text-xs text-muted-foreground">
                                <span>Total shares</span>
                                <span className={totalShare === 100 ? 'text-green-600 font-medium' : 'text-red-600 font-medium'}>
                                  {totalShare.toFixed(2)}% {totalShare === 100 ? '(Valid)' : '(Must equal 100%)'}
                                </span>
                              </div>
                              <div className="mt-1 h-2 overflow-hidden rounded-full bg-muted">
                                <div
                                  className={`h-full transition-all ${totalShare === 100 ? 'bg-green-500' : 'bg-red-500'}`}
                                  style={{ width: `${Math.min(100, totalShare)}%` }}
                                />
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="border-border/60">
                <CardHeader>
                  <CardTitle className="font-jakarta text-lg">All Co-Owner Records</CardTitle>
                </CardHeader>
                <CardContent>
                  {coOwners.length === 0 ? (
                    <p className="text-sm text-muted-foreground">No co-owner records</p>
                  ) : (
                    <div className="space-y-2">
                      {coOwners.slice(0, 30).map((o) => {
                        const prop = properties.find((p) => p.id === o.property_id);
                        return (
                          <div key={o.id} className="flex items-center justify-between border-b border-border/40 pb-2">
                            <div>
                              <p className="text-sm font-medium">{o.name}</p>
                              <p className="text-xs text-muted-foreground">
                                {prop?.dc_title || 'Unknown property'} &middot; {o.phone || 'No phone'}
                              </p>
                            </div>
                            <Badge variant="outline">{Number(o.share_pct).toFixed(2)}%</Badge>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}

          {/* TRANSFERS */}
          {activeTab === 'transfers' && (
            <div className="space-y-2">
              {transfers.length === 0 ? (
                <p className="text-sm text-muted-foreground">No transfers recorded</p>
              ) : (
                transfers.map((t) => (
                  <div key={t.id} className="rounded-lg border border-border/60 p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <FileText size={16} className="text-muted-foreground" />
                        <p className="text-sm font-medium">Transfer ID: {t.transfer_id}</p>
                      </div>
                      <Badge
                        variant={t.status === 'APPROVED' ? 'default' : t.status === 'DISPUTED' ? 'destructive' : 'secondary'}
                      >
                        {t.status}
                      </Badge>
                    </div>
                    <div className="mt-2 grid grid-cols-2 gap-2 text-xs text-muted-foreground md:grid-cols-4">
                      <div>
                        <span className="font-medium text-foreground">Seller:</span> {t.seller_name}
                      </div>
                      <div>
                        <span className="font-medium text-foreground">Buyer:</span> {t.buyer_name}
                      </div>
                      <div>
                        <span className="font-medium text-foreground">Price:</span> {formatNaira(t.sale_price)}
                      </div>
                      <div>
                        <span className="font-medium text-foreground">DC Title:</span> {t.dc_title || '-'}
                      </div>
                    </div>
                    <div className="mt-2 flex flex-wrap gap-2">
                      {t.witness1_phone && (
                        <Badge variant="outline" className={t.witness1_status === 'APPROVED' ? 'border-green-300 text-green-700' : ''}>
                          W1: {t.witness1_status}
                        </Badge>
                      )}
                      {t.witness2_phone && (
                        <Badge variant="outline" className={t.witness2_status === 'APPROVED' ? 'border-green-300 text-green-700' : ''}>
                          W2: {t.witness2_status}
                        </Badge>
                      )}
                      {t.witness3_phone && (
                        <Badge variant="outline" className={t.witness3_status === 'APPROVED' ? 'border-green-300 text-green-700' : ''}>
                          W3: {t.witness3_status}
                        </Badge>
                      )}
                      {t.chief_phone && (
                        <Badge variant="outline" className={t.chief_status === 'APPROVED' ? 'border-green-300 text-green-700' : ''}>
                          Chief: {t.chief_status}
                        </Badge>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {/* USERS */}
          {activeTab === 'users' && (
            <div className="space-y-2">
              {profiles.length === 0 ? (
                <p className="text-sm text-muted-foreground">No users found</p>
              ) : (
                profiles.map((p) => {
                  const Icon = p.role === 'admin' ? ShieldCheck : p.role === 'landlord' ? Home : p.role === 'chief' ? Crown : p.role === 'barrister' ? Scale : User;
                  return (
                    <div key={p.id} className="flex items-center justify-between rounded-lg border border-border/60 p-3">
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted">
                          <Icon size={18} className="text-muted-foreground" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">{p.full_name}</p>
                          <p className="text-xs text-muted-foreground">
                            {p.dc_id} &middot; {p.phone} {p.email ? `&middot; ${p.email}` : ''}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={p.role === 'admin' ? 'default' : 'secondary'} className="capitalize">
                          {p.role}
                        </Badge>
                        <Badge variant="outline" className={p.kyc_status === 'VERIFIED' ? 'border-green-300 text-green-700' : p.kyc_status === 'REJECTED' ? 'border-red-300 text-red-700' : ''}>
                          {p.kyc_status}
                        </Badge>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}

          {/* PAYMENTS */}
          {activeTab === 'payments' && (
            <Card className="border-border/60">
              <CardHeader>
                <CardTitle className="font-jakarta text-lg">All Payments ({payments.length})</CardTitle>
              </CardHeader>
              <CardContent>
                {payments.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No payments recorded</p>
                ) : (
                  <div className="space-y-2">
                    {payments.map((p) => (
                      <div key={p.id} className="flex items-center justify-between border-b border-border/40 pb-2">
                        <div>
                          <p className="text-sm font-medium">{p.type}</p>
                          <p className="text-xs text-muted-foreground">
                            {p.dc_title || '-'} &middot; {p.dc_id || '-'} &middot; {new Date(p.created_at).toLocaleString()}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-sm">{formatNaira(p.amount)}</span>
                          <Badge variant={p.status === 'SUCCESS' ? 'default' : 'destructive'}>
                            {p.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </>
  );
}
