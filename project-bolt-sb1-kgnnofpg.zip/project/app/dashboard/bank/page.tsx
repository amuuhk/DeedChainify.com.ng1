'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Landmark, Activity, Wallet, TrendingUp, Loader2, Key, Copy,
} from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/lib/supabase/client';
import type { Bank, Property, Payment } from '@/lib/supabase/client';
import { SiteHeader } from '@/components/site-header';
import { StatusBadge } from '@/components/status-badge';
import { formatNaira } from '@/lib/dcid';

export default function BankDashboard() {
  const [bank, setBank] = useState<Bank | null>(null);
  const [collateral, setCollateral] = useState<Property[]>([]);
  const [apiCalls, setApiCalls] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetch() {
      const { data: bankData } = await supabase
        .from('banks')
        .select('*')
        .maybeSingle();
      setBank(bankData as Bank | null);

      const { data: propData } = await supabase
        .from('properties')
        .select('*')
        .eq('is_pledged', true);
      setCollateral(propData as Property[] || []);

      const { data: payData } = await supabase
        .from('payments')
        .select('*')
        .eq('type', 'BANK_API')
        .order('created_at', { ascending: false })
        .limit(10);
      setApiCalls(payData as Payment[] || []);

      setLoading(false);
    }
    fetch();
  }, []);

  if (loading) {
    return (
      <>
        <SiteHeader />
        <div className="flex h-[calc(100vh-4rem)] items-center justify-center">
          <Loader2 className="animate-spin text-primary" />
        </div>
      </>
    );
  }

  const apiUsage = bank ? (bank.api_calls_used / bank.api_calls_included) * 100 : 0;

  return (
    <>
      <SiteHeader />
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        <h1 className="font-jakarta text-2xl font-bold">Bank Portal</h1>
        <p className="text-sm text-muted-foreground">Subscription, API usage, and collateral tracker</p>

        <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-4">
          {[
            { label: 'Tier', value: bank?.tier || 'BASIC', icon: Landmark, color: 'text-primary' },
            { label: 'Monthly Fee', value: formatNaira(bank?.monthly_fee || 200000), icon: Wallet, color: 'text-blue-600' },
            { label: 'API Calls Used', value: `${bank?.api_calls_used || 0}/${bank?.api_calls_included || 100}`, icon: Activity, color: 'text-secondary' },
            { label: 'Collateral', value: collateral.length, icon: TrendingUp, color: 'text-green-600' },
          ].map((s) => (
            <Card key={s.label} className="border-border/60">
              <CardContent className="p-4">
                <s.icon size={20} className={s.color} />
                <p className="mt-2 font-jakarta text-xl font-bold">{s.value}</p>
                <p className="text-xs text-muted-foreground">{s.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-8 grid gap-6 lg:grid-cols-2">
          {/* API Usage Chart */}
          <Card className="border-border/60">
            <CardHeader>
              <CardTitle className="font-jakarta text-lg">API Usage</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm">
                    <span>Used: {bank?.api_calls_used || 0}</span>
                    <span className="text-muted-foreground">Limit: {bank?.api_calls_included || 100}</span>
                  </div>
                  <div className="mt-2 h-4 overflow-hidden rounded-full bg-muted">
                    <div
                      className={`h-full transition-all ${apiUsage > 80 ? 'bg-red-500' : 'bg-primary'}`}
                      style={{ width: `${Math.min(100, apiUsage)}%` }}
                    />
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {apiUsage.toFixed(0)}% of monthly quota used
                  </p>
                </div>

                <div className="rounded-lg border border-border/60 bg-muted/30 p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Key size={16} className="text-primary" />
                      <span className="text-sm font-medium">API Key</span>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        navigator.clipboard.writeText(bank?.api_key || '');
                        toast.success('API key copied');
                      }}
                    >
                      <Copy size={14} className="mr-1.5" />
                      Copy
                    </Button>
                  </div>
                  <p className="mt-2 font-mono text-xs text-muted-foreground break-all">
                    {bank?.api_key?.substring(0, 20)}...
                  </p>
                </div>

              </div>
            </CardContent>
          </Card>

          {/* Collateral Tracker */}
          <Card className="border-border/60">
            <CardHeader>
              <CardTitle className="font-jakarta text-lg">Collateral Tracker</CardTitle>
            </CardHeader>
            <CardContent>
              {collateral.length === 0 ? (
                <div className="flex flex-col items-center py-8 text-center">
                  <Landmark size={32} className="text-muted-foreground" />
                  <p className="mt-2 text-sm text-muted-foreground">No collateral pledged</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {collateral.map((p) => (
                    <div key={p.id} className="rounded-lg border border-blue-300 bg-blue-50 p-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium">{p.dc_title}</p>
                          <p className="text-xs text-muted-foreground">
                            {p.owner_name} &middot; {p.size_sqm} sqm
                          </p>
                        </div>
                        <StatusBadge status={p.status} isPledged={p.is_pledged} bankName={p.bank_name} />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Recent API Calls */}
        <Card className="mt-6 border-border/60">
          <CardHeader>
            <CardTitle className="font-jakarta text-lg">Recent API Calls</CardTitle>
          </CardHeader>
          <CardContent>
            {apiCalls.length === 0 ? (
              <p className="text-sm text-muted-foreground">No API calls recorded</p>
            ) : (
              <div className="space-y-2">
                {apiCalls.map((c) => (
                  <div key={c.id} className="flex items-center justify-between border-b border-border/40 pb-2">
                    <div>
                      <p className="text-sm font-medium">{c.dc_title || 'Person lookup'}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(c.created_at).toLocaleString()}
                      </p>
                    </div>
                    <span className="font-semibold text-sm">{formatNaira(c.amount)}</span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </>
  );
}
